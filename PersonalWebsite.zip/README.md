# PersonalWebsite

## [Zunanafikri.com](https://zunanalfikri.com)

Website Pribadi dengan template dari Colorlib. Link bisa diakses [disini](https://colorlib.com/wp/template/ronaldo/?v=b718adec73e0).

Contoh Tampilan :
![image](https://user-images.githubusercontent.com/47711509/78313639-a7858d80-7581-11ea-90b7-79f5bffb2431.png)

